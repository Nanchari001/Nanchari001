import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'card-ui';

  monthOption: string[] = [];
  yearOption: string[] = [];
  brandImage: string = "../assets/images/visa.png";
  inputCardNumber: string = ""
  cardNumber: string[] = ['#', '#', '#', '#', '#', '#', '#', '#', '#', '#', '#', '#', '#', '#', '#', '#'];
  inputCardHolder: string = "";
  cardHolder: string = "AD SOYAD";
  cardMonth: string = "MM /";
  cardYear: string = "YY"
  inputCardCVV: string = "";
  cardCVV: string = "****";
  isCVVChange: boolean = false;
  oldCardNumber: string = "";

  isCardNumberFocus: boolean = false;
  isCardHolderFocus: boolean = false;
  isCardDateFocus: boolean = false;

  regexMap = [
    { regEx: /^4[0-9]{5}/ig, cardType: "VISA" },
    { regEx: /^5[1-5][0-9]{4}/ig, cardType: "MASTERCARD" },
    { regEx: /^3[47][0-9]{3}/ig, cardType: "AMEX" },
    { regEx: /^(5[06-8]\d{4}|6\d{5})/ig, cardType: "DISCOVER" }
  ];

  constructor() {
    for (var _i = 1; _i < 13; _i++) {
      var number = this.toString(_i);
      this.monthOption.push(number);
    }

    let date = new Date();
    for (var _i = date.getFullYear(); _i < (date.getFullYear() + 10); _i++) {
      this.yearOption.push(_i.toString());
    }


  }

  toString(d: number) {
    return (d < 10) ? '0' + d.toString() : d.toString();
  }

  submitClick() {
  }

  showBackFace() {
    this.isCVVChange = true;
  }

  showFrontFace() {
    this.isCVVChange = false;
  }

  onCardNumberEntry(event: any) {
    this.isCVVChange = false;

    if (this.inputCardNumber.length < 17) {
      this.cardNumberBind(this.inputCardNumber, event);
    }
    else {
      this.inputCardNumber = this.inputCardNumber.slice(0, 16);
    }

  }

  onCardNameEntry() {
    if (this.inputCardHolder.length < 1) {
      this.cardHolder = "AD SOYAD";
    } else {
      this.cardHolder = this.inputCardHolder.toUpperCase();
    }

  }

  onCardMonthEntry(event: any) {
    if (event.value.length < 1) {
      this.cardMonth = "MM /";
    } else {
      this.cardMonth = event.value + " /";
    }
  }

  onCardYearEntry(event: any) {
    if (event.value.length < 1) {
      this.cardYear = "YY";
    } else {
      var year = event.value.slice(2);
      this.cardYear = year;
    }
  }

  onCardCVVEntry() {
    if ((this.inputCardCVV.length < 1)) {
      this.cardCVV = "****";
    }
    else {
      if (!(this.inputCardCVV.length > 4)) {
        this.cardCVV = this.inputCardCVV;
      }
    }

  }

  cvvChange() {
    if (this.inputCardCVV.length > 4) {
      var cvv = this.inputCardCVV.slice(0, 4);
      this.inputCardCVV = cvv;
    }
  }

  cardNumberBind(oldValue: string, newValue: string) {
    for (var i = 0; i < this.regexMap.length; i++) {
      var regex = new RegExp(this.regexMap[i].regEx);

      if (regex.test(this.inputCardNumber)) {
        this.brandImage = "../assets/images/" + this.regexMap[i].cardType.toLowerCase() + ".png";
        i = this.regexMap.length;
      }
      else {
        this.brandImage = "../assets/images/visa.png";
      }
    }

    if (!(oldValue.length > newValue.length)) {
      var lastItem = newValue.charAt(newValue.length - 1);
      this.cardNumber[newValue.length - 1] = lastItem;
    }
    else {
      this.cardNumber[oldValue.length - 1] = "#";
    }

  }

  isNumber(event: any) {
    if (event.keyCode > 31 && (event.keyCode < 48 || event.keyCode > 57) || (this.inputCardNumber.length > 15)) {
      return false;
    }
    return true;
  }

  isCVVNumber(event: any) {
    if (event.keyCode > 31 && (event.keyCode < 48 || event.keyCode > 57) || (this.inputCardCVV.length > 3)) {
      return false;
    }
    return true;
  }

  isAlphabet(event: any) {
    if ((event.keyCode > 64 && event.keyCode < 91) || (event.keyCode > 96 && event.keyCode < 123) || (event.keyCode == 32)) {
      return true;
    }
    return false;
  }

  onNumberFocus() {
    this.isCardNumberFocus = true;
    this.oldCardNumber = this.inputCardNumber;
  }

  onNumberBlur() {
    this.isCardNumberFocus = false;
  }

  onNameFocus() {
    this.isCardHolderFocus = true;
  }

  onNameBlur() {
    this.isCardHolderFocus = false;
  }

  onDateFocus() {
    this.isCardDateFocus = true;
  }

  onDateBlur() {
    this.isCardDateFocus = false;
  }

}
